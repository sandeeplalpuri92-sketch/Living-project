package com.livingsound.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaPlayer
import android.media.audiofx.Visualizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var visual: UniverseView
    private lateinit var status: TextView
    private lateinit var playButton: Button
    private var player: MediaPlayer? = null
    private var visualizer: Visualizer? = null
    private var audioUri: Uri? = null
    private var playing = false
    private var mode = 0
    private val pickAudio = 41
    private val audioPermission = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5, 7, 20)
        window.navigationBarColor = Color.rgb(5, 7, 20)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(14))
            setBackgroundColor(Color.rgb(5, 7, 20))
        }
        val title = TextView(this).apply {
            text = "LIVING SOUND"
            textSize = 25f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            letterSpacing = .18f
        }
        val subtitle = TextView(this).apply {
            text = "3D MUSIC UNIVERSE"
            textSize = 11f
            setTextColor(Color.rgb(157, 170, 220))
            gravity = Gravity.CENTER
            letterSpacing = .25f
        }
        visual = UniverseView(this)
        status = TextView(this).apply {
            text = "Choose a song to awaken the universe"
            textSize = 12f
            setTextColor(Color.rgb(176, 190, 230))
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
        }
        val choose = makeButton("♫  CHOOSE MUSIC").also {
            it.setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "audio/*"
                }
                startActivityForResult(intent, pickAudio)
            }
        }
        playButton = makeButton("▶  PLAY").also {
            it.isEnabled = false
            it.alpha = .5f
            it.setOnClickListener { togglePlayback() }
        }
        val modes = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        listOf("COSMIC", "RINGS", "NEBULA", "TUNNEL").forEachIndexed { index, name ->
            val b = Button(this).apply {
                text = name
                textSize = 9f
                setTextColor(Color.WHITE)
                setBackgroundColor(if (index == 0) Color.rgb(91, 61, 160) else Color.rgb(24, 34, 62))
                setPadding(dp(2), 0, dp(2), 0)
                setOnClickListener {
                    mode = index
                    visual.mode = index
                    visual.invalidate()
                    for (i in 0 until modes.childCount) {
                        (modes.getChildAt(i) as Button).setBackgroundColor(
                            if (i == index) Color.rgb(91, 61, 160) else Color.rgb(24, 34, 62)
                        )
                    }
                }
            }
            modes.addView(b, LinearLayout.LayoutParams(0, dp(46), 1f).apply {
                setMargins(dp(2), 0, dp(2), 0)
            })
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(visual, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ).apply { topMargin = dp(14); bottomMargin = dp(8) })
        root.addView(status)
        root.addView(choose, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(8) })
        root.addView(playButton, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(10) })
        root.addView(modes, LinearLayout.LayoutParams(-1, dp(48)))
        setContentView(root)
    }

    private fun makeButton(label: String) = Button(this).apply {
        text = label
        textSize = 13f
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(37, 47, 83))
    }

    private fun togglePlayback() {
        val p = player
        if (p == null) {
            Toast.makeText(this, "Pehle music select karein", Toast.LENGTH_SHORT).show()
            return
        }
        if (playing) {
            p.pause()
            playing = false
            playButton.text = "▶  PLAY"
            status.text = "PAUSED • Universe resting"
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), audioPermission)
                return
            }
            try {
                p.start()
                playing = true
                attachVisualizer(p.audioSessionId)
                playButton.text = "Ⅱ  PAUSE"
                status.text = "● LIVE • Sound detected"
                visual.startAnimation()
            } catch (e: Exception) {
                Toast.makeText(this, "Playback start nahi ho paya", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun attachVisualizer(sessionId: Int) {
        try {
            visualizer?.release()
            visualizer = Visualizer(sessionId).apply {
                captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(512)
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, rate: Int) {}
                    override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, rate: Int) {
                        if (fft != null) visual.setFft(fft)
                    }
                }, Visualizer.getMaxCaptureRate() / 2, false, true)
                enabled = true
            }
        } catch (_: Exception) {
            status.text = "● PLAYING • Visualizer permission/device limitation"
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermission && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED) togglePlayback()
        else if (requestCode == audioPermission) {
            Toast.makeText(this, "Live beat effects ke liye audio permission zaroori hai", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Legacy document picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickAudio && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            audioUri = uri
            try {
                player?.release()
                player = MediaPlayer().apply {
                    setDataSource(this@MainActivity, uri)
                    setOnCompletionListener {
                        playing = false
                        playButton.text = "▶  PLAY"
                        status.text = "FINISHED • Choose another song"
                    }
                    prepare()
                }
                playButton.isEnabled = true
                playButton.alpha = 1f
                status.text = "Song ready • Press PLAY"
            } catch (e: Exception) {
                Toast.makeText(this, "Ye audio file play nahi ho pa rahi", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onPause() {
        super.onPause()
        if (playing) {
            player?.pause()
            playing = false
            if (::playButton.isInitialized) playButton.text = "▶  PLAY"
        }
    }

    override fun onDestroy() {
        visualizer?.release()
        player?.release()
        visual.stopAnimation()
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
