package com.livingsound.app

import android.content.Context
import android.graphics.*
import android.view.View
import android.os.Handler
import android.os.Looper
import kotlin.math.*
import kotlin.random.Random

class UniverseView(context: Context) : View(context) {
    var mode = 0
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fft = FloatArray(128)
    private var phase = 0.0
    private var animating = false
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            if (animating) {
                phase += .025
                invalidate()
                handler.postDelayed(this, 33)
            }
        }
    }
    private val stars = Array(170) {
        Star(Random.nextFloat(), Random.nextFloat(), .5f + Random.nextFloat() * 2f, Random.nextFloat() * 6.28f)
    }
    private data class Star(val x: Float, val y: Float, val size: Float, val angle: Float)

    fun startAnimation() {
        if (!animating) { animating = true; handler.post(tick) }
    }
    fun stopAnimation() { animating = false; handler.removeCallbacks(tick) }
    fun setFft(bytes: ByteArray) {
        val n = min(fft.size, bytes.size / 2)
        for (i in 0 until n) {
            val re = bytes[i * 2].toInt()
            val im = bytes[i * 2 + 1].toInt()
            fft[i] = (sqrt((re * re + im * im).toDouble()) / 128.0).toFloat().coerceIn(0f, 1f)
        }
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val base = min(w, h)
        val bass = fft.take(12).average().toFloat()
        val pulse = 1f + bass * 1.1f
        canvas.drawColor(Color.rgb(5, 7, 20))
        paint.shader = RadialGradient(cx, cy, base * .65f,
            intArrayOf(Color.rgb(35, 38, 88), Color.rgb(12, 17, 42), Color.BLACK),
            floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null

        stars.forEach { s ->
            val twinkle = .35f + .65f * abs(sin(phase * 2 + s.angle))
            paint.color = Color.argb((twinkle * 210).toInt(), 155, 190, 255)
            canvas.drawCircle(s.x * w, s.y * h, s.size, paint)
        }

        if (mode == 3) {
            for (i in 0 until 15) {
                val t = (i / 15f + (phase.toFloat() * .07f % 1f))
                val r = base * (.08f + t * .44f)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 1.5f + bass * 5
                paint.color = Color.argb((220 * (1f - t * .65f)).toInt(), 75, 205, 255)
                canvas.drawOval(cx - r, cy - r * .72f, cx + r, cy + r * .72f, paint)
            }
        } else {
            for (ring in 0..4) {
                val r = base * (.13f + ring * .055f) * pulse
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 1.2f + bass * 4
                paint.color = Color.argb(170 - ring * 22, 120 + ring * 15, 110, 255)
                val rect = RectF(cx-r, cy-r, cx+r, cy+r)
                canvas.save()
                canvas.rotate((phase * (if (ring % 2 == 0) 1 else -1) * 13).toFloat(), cx, cy)
                canvas.drawOval(rect, paint)
                canvas.restore()
            }
            for (i in 0 until 128) {
                val angle = i * 2.0 * Math.PI / 128.0 + phase * .12
                val value = fft[i]
                val inner = base * .22f * pulse
                val outer = inner + base * (.025f + value * .20f)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2f + value * 2f
                paint.color = Color.HSVToColor(220, floatArrayOf((185 + i * 1.2f) % 360, .75f, 1f))
                canvas.drawLine(
                    cx + cos(angle).toFloat() * inner, cy + sin(angle).toFloat() * inner,
                    cx + cos(angle).toFloat() * outer, cy + sin(angle).toFloat() * outer, paint
                )
            }
        }

        if (mode == 2) {
            for (i in 0 until 90) {
                val a = i * Math.PI * 2 / 90 + phase
                val v = fft[i % fft.size]
                val r = base * (.22f + v * .22f)
                paint.style = Paint.Style.FILL
                paint.color = Color.HSVToColor(210, floatArrayOf((170 + i * 2.0f) % 360, .8f, 1f))
                canvas.drawCircle(cx + cos(a).toFloat() * r, cy + sin(a).toFloat() * r, 2f + v * 5f, paint)
            }
        }

        val radius = base * .115f * pulse
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(cx - radius * .25f, cy - radius * .3f, radius * 1.5f,
            intArrayOf(Color.WHITE, Color.rgb(120, 220, 255), Color.rgb(105, 70, 220), Color.TRANSPARENT),
            null, Shader.TileMode.CLAMP)
        paint.setShadowLayer(24f + bass * 45f, 0f, 0f, Color.rgb(130, 100, 255))
        canvas.drawCircle(cx, cy, radius * 1.55f, paint)
        paint.clearShadowLayer()
        paint.shader = null
        paint.style = Paint.Style.FILL
    }
}
