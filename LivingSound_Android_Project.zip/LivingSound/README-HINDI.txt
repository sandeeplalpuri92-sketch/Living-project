LIVING SOUND – Android Project

Kya hai:
- Android music player (phone se audio file select)
- Live FFT audio visualizer
- Cosmic, Rings, Nebula aur Tunnel modes
- Android 6.0+ (minSdk 23), Android 12 par compatible target

APK banane ke liye:
1. Computer par Android Studio install karein.
2. Android Studio > Open > is ZIP ko extract karke LivingSound folder select karein.
3. Gradle sync complete hone dein.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK app/build/outputs/apk/debug/app-debug.apk mein milega.

Pehli baar Play dabane par microphone/audio capture permission maangi ja sakti hai.
Ye permission Android Visualizer API ke live frequency data ke liye hai.
Audio file Android document picker se select hoti hai; app ko broad storage access nahi chahiye.

Note:
- Ye Android Studio source project hai, precompiled APK nahi.
- Debug APK testing ke liye hota hai. Public distribution se pehle release signing aur device testing karein.
- Kuch devices par manufacturer audio effects ki wajah se live FFT capture restricted ho sakta hai.
